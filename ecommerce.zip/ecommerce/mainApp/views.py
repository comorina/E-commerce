from django.shortcuts import render,redirect,HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *
from django.db.models import Q

# Create your views here.
def home(request):
	if request.method=='POST':
		msg=request.POST.get('message')
		p=Product.objects.filter(Q(name_icontains=msg))
	else:
		p=Product.objects.all()
	return render(request,'index.html',{'Product':p})		